// const RequestBtn = document.querySelector("request");

// document.addEventListener('DOMContentLoaded', function () {
   

//     RequestBtn.addEventListener('click', function () {
//         RequestBtn.textContent = 'Sent';
//     });
// });